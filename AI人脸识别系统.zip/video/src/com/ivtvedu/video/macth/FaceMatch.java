package com.ivtvedu.video.macth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ivtvedu.video.utils.AuthService;
import com.ivtvedu.video.utils.Base64Util;
import com.ivtvedu.video.utils.FileUtil;
import com.ivtvedu.video.utils.GsonUtils;
import com.ivtvedu.video.utils.HttpUtil;


public class FaceMatch {
	
	public static String match(String path1 , String path2){
		String result = null;
		try {
			//1.׼���ٶ�AI�ӿ� ����ʶ�������Աȣ�������·��
			String url = "https://aip.baidubce.com/rest/2.0/face/v3/match";
			
			//2.��ȡ�ٶ����ƣ�ǩ����
			String token = AuthService.getAuth();
			
			//3.׼�������Ա���Ҫ�Ĳ���
			Map<String, Object> map1 = new HashMap<String, Object>();
			String data1 = Base64Util.encode( FileUtil.readFileByBytes(path1) );
			map1.put("image", data1);
			map1.put("image_type", "BASE64");
			
			Map<String, Object> map2 = new HashMap<String, Object>();
			String data2 = Base64Util.encode( FileUtil.readFileByBytes(path2) );
			map2.put("image", data2);
			map2.put("image_type", "BASE64");
			
			List<Map> list = new ArrayList<Map>();
			list.add(map1);
			list.add(map2);
			String params = GsonUtils.toJson(list);
			
			//��ٶ�AI���������Աȵ�����
			result = HttpUtil.post(url, token, params);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
